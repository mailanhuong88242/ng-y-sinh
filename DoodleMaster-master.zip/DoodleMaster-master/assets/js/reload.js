function refresh() {
    window.location.reload(true);
}

setInterval(refresh, 1000);
